
document.addEventListener("DOMContentLoaded", () => {
  // Obtener el formulario y el contenedor de productos
  const form = document.querySelector("[data-form]");
  const productsContainer = document.querySelector("[data-product]");
  const messageError = form.querySelector("[data-mensage]");

  // Escuchar el evento de envío del formulario
  form.addEventListener("submit", (event) => {
      event.preventDefault(); // Evitar que se recargue la página

      const name = form.querySelector("[data-name]").value;
      const price = form.querySelector("[data-price]").value;
      const image = form.querySelector("[data-image]").value;

      // Verificar si los campos no están vacíos
      if (name && price && image) {
          // Crear una nueva tarjeta de producto
          const productCard = document.createElement("div");
          productCard.classList.add("product-card");

          // Crear un ícono de basura (botón de eliminación)
          const deleteIcon = document.createElement("button");
          deleteIcon.classList.add("delete-icon");
          deleteIcon.innerHTML = '🗑️';  // Puedes usar un ícono de texto o una imagen aquí

          // Insertar el contenido de la tarjeta, incluyendo el ícono de basura
          productCard.innerHTML = `
              <img src="${image}" alt="${name}" class="product-image">
              <h3 class="product-name">${name}</h3>
              <p class="product-price">$${price}</p>
          `;
          
          // Agregar el ícono de eliminar al final de la tarjeta
          productCard.appendChild(deleteIcon);

          // Insertar la tarjeta en el contenedor de productos
          productsContainer.appendChild(productCard);

          // Agregar el evento de eliminar la tarjeta al hacer clic en el ícono
          deleteIcon.addEventListener("click", () => {
              productCard.remove(); // Eliminar la tarjeta del DOM
          });

          // Limpiar el formulario
          form.reset();
          messageError.textContent = ""; // Limpiar mensaje de error
      } else {
          // Si algún campo está vacío, mostrar un mensaje de error
          messageError.textContent = "Por favor, complete todos los campos.";
      }
  });
});
